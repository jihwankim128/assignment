clear all
close all
clc

y = 1/2;
T_0 = 2; % Fundamental Period
freq_0 = 1/T_0; % Fundamental Frequency

T_s = 0.001;
t = -1:T_s:1;



y=y+2*((2*cos(pi*t)/pi)-sin(i*t)-sin(2*pi*t)/2)/pi;
y=y+2*((2*cos(3*pi*t)/9*pi)-(sin(i*t)/3)-sin(4*pi*t)/2)/pi;
%for i=1:1000
 % A=((2-2*cos(i*pi))/i^2*pi^2)*cos(i*pi*t);
 % B=((2*sin(i*pi)-2*i*pi)/i^2*pi^2)*sin(i*pi*t);

  %y=y+A+B;
  %hold off
  %plot(t, f_t);
 % hold on
  plot(t,y);
  hold on
  grid on

 % pause(0.00001)
%end
