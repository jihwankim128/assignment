#include <GL/glut.h>
#include <math.h>
#define gf GLfloat
#define w_w 700
#define w_h 700

gf camx = 0, camy = 2, camz = 4;
gf cam2x = 0.0, cam2y = 0.0, cam2z = 0.0;
gf cam_upx = 0.0, cam_upy = 1.0, cam_upz = 0.0;

void InitLight() {
    glEnable(GL_LIGHTING);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
}

void MyDisplay() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(camx, camy, camz,
        cam2x, cam2y, cam2z,
        cam_upx, cam_upy, cam_upz);
    
    gf lga[] = { 0.3, 0.3, 0.3, 1.0 };
    gf lp[] = { 2, 2, -2, 1 };
    gf ldir[] = { -1, -1, 1 };
    gf spot[] = { 2 };

    gf la[] = { 1, 1, 1, 1.0 };
    gf ld[] = { 0, 0.0, 1, 1.0 };
    gf ls[] = { 1.0, 1.0, 1.0, 1.0 };

    glEnable(GL_LIGHT0);

    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lga);

    glLightfv(GL_LIGHT0, GL_AMBIENT, la);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, ld);
    glLightfv(GL_LIGHT0, GL_SPECULAR, ls);

    glDisable(GL_COLOR_MATERIAL);
    
    gf ma[] = { 0.3, 0.3, 0.3, 1.0 };
    gf md[] = { 0.8, 0.0, 0.0, 1.0 };
    gf ms[] = { 1.0, 1.0, 1.0, 1.0 };
    gf msh[] = { 25.0 };
    glMaterialfv(GL_FRONT, GL_AMBIENT, ma);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, md);
    glMaterialfv(GL_FRONT, GL_SPECULAR, ms);
    glMaterialfv(GL_FRONT, GL_SHININESS, msh);

    glBegin(GL_QUADS); 

    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);



    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);

    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glEnd();

    glEnable(GL_COLOR_MATERIAL);
    glFlush();
}
void res(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gf ratio = (gf)w / (gf)h;
    gluPerspective(40, ratio, 0.1, 10);
}

int main(int a, char** c) {
    glutInit(&a, c);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(w_w, w_h);
    glutInitWindowPosition(50, 50);
    glClearColor(0, 0, 0, 0);

    glutCreateWindow("test");
    InitLight();

    glutDisplayFunc(MyDisplay);
    glutReshapeFunc(res);

    glutMainLoop();
    return 0;
}