#include <gl\glut.h>
#include <gl\gl.h>
#include <gl\glu.h>
static int Day = 0, Time = 0;

void MyDisplay() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    glPushMatrix();
    glColor3f(0.7, 0.7, 0.7);
    glBegin(GL_POLYGON);
    glVertex3f(-1, 0.5, 0);
    glVertex3f(-1, -1, 0);
    glVertex3f(1, -1, 0);
    glVertex3f(1, 0.5, 0);
    glPopMatrix();
    glEnd();

    glPushMatrix();
    glColor3f(1, 0, 0);
    glTranslated(-0.3, 0.4, 0.0);
    glutWireSphere(0.2, 20, 20);
    glColor3f(0, 0, 1);
    glTranslated(0.6, -1.0, 0.0);
    glutWireSphere(0.2, 20, 20);
    glTranslated(-0.6, 0.5, 0);
    glColor3f(1, 1, 0);
    glScalef(0.6, 2.0, 0);
    glRotatef(-10, 0, 0.1, 0);
    glutWireCube(0.4);
    glPopMatrix();
     

    glPushMatrix();
    glColor3f(1, 0, 0);
    glTranslated(0.3, 0.4, 0.0);
    glutWireSphere(0.2, 20, 20);
    glColor3f(0, 0, 1);
    glTranslated(-0.6, -1.0, 0.0);
    glutWireSphere(0.2, 20, 20);
    glTranslated(0.6, 0.5, 0);
    glColor3f(1, 1, 0);
    glScalef(0.6, 2.0, 0);
    glRotatef(-10, 0, 0.1, 0);
    glutWireCube(0.4);
    glPopMatrix();

    glPushMatrix();
    glColor3f(1, 0, 0);
    glTranslated(0.7, -0.1, 0.0);
    glutWireSphere(0.2, 20, 20);
    glColor3f(0, 0, 1);
    glTranslated(-1.4, 0.0, 0.0);
    glutWireSphere(0.2, 20, 20);
    glTranslated(0.7, 0.0, 0);
    glColor3f(1, 1, 0);
    glScalef(3.0, 0.6, 0);
    glRotated(-10, 1, 0, 0);
    glutWireCube(0.4);
    glPopMatrix();

    glutSwapBuffers();
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("OpenGL Sample Drawing");
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glLoadIdentity();
    glutDisplayFunc(MyDisplay);
    glutMainLoop();
    return 0;
}
